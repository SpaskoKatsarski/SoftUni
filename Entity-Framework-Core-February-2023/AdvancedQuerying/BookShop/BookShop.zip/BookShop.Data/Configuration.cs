﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=.\SQLEXPRESS;Database=database_name;Integrated Security=true;TrustServerCertificate=true";
    }
}
