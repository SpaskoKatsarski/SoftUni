﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T02.VehiclesExtension
{
    public interface IEngine
    {
        void Start();
    }
}
