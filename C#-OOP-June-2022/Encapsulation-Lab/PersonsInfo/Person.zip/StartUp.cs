﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Spasko", "Katsarski", 16, 2000);
            Person person2 = new Person("Ivan", "ADAD", 46, 2000);
            Person person3 = new Person("Gosho", "GDG", 30, 2000);
            Person person4 = new Person("Dancho", "SSSS", 40, 2000);
            Person person5 = new Person("Petko", "FAMILY", 12, 2000);

            List<Person> persons = new List<Person>();

            persons.Add(person1);
            persons.Add(person2);
            persons.Add(person3);
            persons.Add(person4);
            persons.Add(person5);

            Team team = new Team("SoftUni");

            foreach (Person person in persons)
            {
                team.AddPlayer(person);
            }

            Console.WriteLine(team.FirstTeam.Count);
            Console.WriteLine(team.ReserveTeam.Count);
        }
    }
}
