﻿namespace LineNumbers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lines = File.ReadAllLines(inputFilePath);

            List<string> outputList = new List<string>();

            int count = 0;

            foreach (var line in lines)
            {
                int letters = line.Count(char.IsLetter);
                int symbols = line.Count(char.IsPunctuation);

                outputList.Add($"Line {++count}: {line} ({letters})({symbols})");
            }

            File.WriteAllLines(outputFilePath, outputList);
        }
    }
}
